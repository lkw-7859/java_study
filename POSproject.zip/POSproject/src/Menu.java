
public interface Menu {
	int KIMBAB = 1;
	int TUNAKIMBAB = 2;
}
